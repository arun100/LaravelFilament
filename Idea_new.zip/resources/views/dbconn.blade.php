<div>
<?php
 if(DB::connection()->getPdo()){
    echo 'Database connected';
 }

?>
</div>
