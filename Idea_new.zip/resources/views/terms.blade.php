@extends('layout.layout')

@section('content')
    <h1>Terms</h1>
    <div>
        Our terms & condition
    </div>
@endsection
