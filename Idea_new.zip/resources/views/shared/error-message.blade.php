<div class="alert alert-danger alert-dismissible fade show" role="alert">
    Idea created Successfully
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
